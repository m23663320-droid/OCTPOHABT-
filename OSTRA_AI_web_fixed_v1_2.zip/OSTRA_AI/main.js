const $ = (s) => document.querySelector(s);
const DEFAULT_MODEL = "Qwen2.5-0.5B-Instruct-q4f16_1-MLC";
let engine = null;
let loading = false;
let active = [];
let chats = [];
let busy = false;

const modelLabel = (id) => id.includes("0.5B") ? "Qwen 0.5B" : id.includes("1.5B") ? "Qwen 1.5B" : "Qwen 3B";
function setStatus(title, detail="", ready=false) {
  $("#modelState").textContent = title;
  $("#modelDescription").textContent = detail || (ready ? "Модель готова. Запросы обрабатываются на этом устройстве." : "Первый запуск требует загрузки модели.");
  $("#modelLed").classList.toggle("ready", ready);
  $("#modelHint").textContent = ready ? `Локальная модель: ${modelLabel($("#modelChoice").value)}` : "Сначала загрузи локальную модель";
}
function progress(report) {
  const wrap=$("#progressWrap"), bar=$("#progressBar"), text=$("#progressText");
  wrap.classList.remove("hidden");
  const pct = Math.max(0, Math.min(100, Math.round((report.progress || 0)*100)));
  bar.style.width = `${pct}%`;
  text.textContent = report.text || `Загрузка модели: ${pct}%`;
}
function openSettings() { $("#settings").classList.remove("hidden"); }
function closeSettings() { $("#settings").classList.add("hidden"); }
$("#settingsTop").onclick=openSettings;
$("#settingsClose").onclick=closeSettings;
$("#closeModelSettings").onclick=closeSettings;
$("#modelChoice").value=localStorage.getItem("ostra_model") || DEFAULT_MODEL;

async function loadModel() {
  if (loading || engine) return;
  loading=true;
  const model=$("#modelChoice").value;
  $("#loadModel").disabled=true;
  $("#loadModel").textContent="Подключаем движок…";
  $("#loadModelFromSettings").disabled=true;
  $("#loadModelFromSettings").textContent="Подключаем движок…";
  if (!navigator.gpu) {
    setStatus("На этом устройстве нет WebGPU", "Открой OSTRA по HTTPS в актуальном Chrome или Edge на совместимом устройстве. На некоторых телефонах WebGPU недоступен.", false);
    $("#loadModel").disabled=false;
    $("#loadModel").textContent="Попробовать снова";
    $("#loadModelFromSettings").disabled=false;
    $("#loadModelFromSettings").textContent="Попробовать снова";
    loading=false;
    return;
  }
  localStorage.setItem("ostra_model",model);
  $("#loadModel").textContent="Загружаем нейросеть…";
  $("#loadModelFromSettings").textContent="Загружаем нейросеть…";
  setStatus("Проверяем WebGPU", "Подключаем движок WebLLM и проверяем графический процессор. Не закрывай страницу.");
  try {
    const { CreateMLCEngine } = await import("https://esm.run/@mlc-ai/web-llm");
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) throw new Error("Браузер не смог получить WebGPU-адаптер. Проверь поддержку GPU и обнови браузер.");
    engine=await CreateMLCEngine(model, {
      initProgressCallback: progress,
      logLevel:"WARN"
    });
    setStatus("OSTRA готова к работе", "Модель загружена и сохранена в кэше браузера. При наличии кэша следующие запуски будут быстрее.", true);
    $("#loadModel").textContent="✓ ИИ загружен";
    $("#loadModel").disabled=true;
    $("#loadModelFromSettings").textContent="✓ ИИ загружен";
    $("#loadModelFromSettings").disabled=true;
    closeSettings();
  } catch(err) {
    engine=null;
    setStatus("Не удалось запустить модель", `${err.message || err}. Проверь поддержку WebGPU, свободную память и подключение к интернету.`, false);
    $("#loadModel").textContent="Повторить загрузку";
    $("#loadModel").disabled=false;
    $("#loadModelFromSettings").textContent="Повторить загрузку";
    $("#loadModelFromSettings").disabled=false;
  } finally { loading=false; }
}
$("#loadModel").onclick=loadModel;
$("#loadModelFromSettings").onclick=loadModel;

function addMessage(role, content) {
  const el=document.createElement("div"); el.className=`message ${role}`;
  const avatar=document.createElement("div"); avatar.className="avatar"; avatar.textContent=role==="user"?"Я":"O";
  const bubble=document.createElement("div"); bubble.className="bubble"; bubble.textContent=content;
  el.append(avatar,bubble); $("#messages").append(el); return bubble;
}
function renderHistory() {
  const h=$("#history"); h.innerHTML="";
  chats.forEach(c=>{const b=document.createElement("button");b.textContent=c.title;b.onclick=()=>{active=c.messages;renderMessages()};h.append(b)});
}
function renderMessages() {
  $("#welcome").style.display=active.length?"none":"block";
  $("#messages").style.display=active.length?"block":"none";
  $("#messages").innerHTML="";
  active.forEach(m=>addMessage(m.role==="assistant"?"assistant":"user",m.content));
}
async function send(text) {
  if(busy||!text.trim()) return;
  if(!engine){openSettings();setStatus("Сначала загрузи модель","Для первого запуска нужен интернет и примерно 950 МБ свободного места.",false);return;}
  busy=true;$("#send").disabled=true;$("#welcome").style.display="none";$("#messages").style.display="block";
  active.push({role:"user",content:text});addMessage("user",text);
  const bubble=addMessage("assistant","OSTRA думает…");
  try {
    const messages=[{role:"system",content:"Ты OSTRA — дружелюбный персональный ИИ-ассистент. Отвечай на языке пользователя, ясно, полезно и честно. Ты работаешь локально на устройстве пользователя."},...active];
    const stream=await engine.chat.completions.create({messages,stream:true,temperature:0.7,max_tokens:700});
    let answer="";
    for await (const chunk of stream) {
      const token=chunk.choices?.[0]?.delta?.content || "";
      answer+=token;bubble.textContent=answer || "OSTRA думает…";
    }
    if(!answer) answer="Не удалось получить текстовый ответ.";
    active.push({role:"assistant",content:answer});
  } catch(err) { bubble.textContent=`Ошибка генерации: ${err.message || err}`; }
  if(!chats.some(c=>c.messages===active)) chats.unshift({title:active.find(m=>m.role==="user")?.content.slice(0,36)||"Новый диалог",messages:active});
  renderHistory();busy=false;$("#send").disabled=false;
}
$("#composer").addEventListener("submit",e=>{e.preventDefault();const v=$("#prompt").value;$("#prompt").value="";send(v)});
$("#prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("#composer").requestSubmit()}});
document.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>send(b.dataset.prompt));
$("#newChat").onclick=()=>{if(active.length)chats.unshift({title:active.find(m=>m.role==="user")?.content.slice(0,36)||"Диалог",messages:active});active=[];renderMessages();renderHistory();$("#prompt").focus();$("#sidebar").classList.remove("open")};
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
if(localStorage.getItem("ostra_model")) $("#modelChoice").value=localStorage.getItem("ostra_model");
setStatus("ИИ ещё не загружен","Выбери модель и скачай её один раз. Для самой загрузки нужен интернет.");
